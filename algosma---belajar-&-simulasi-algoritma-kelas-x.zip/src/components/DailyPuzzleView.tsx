import React, { useState } from 'react';
import { DailyPuzzle, Student } from '../types';
import { DAILY_PUZZLES } from '../data/learningModules';
import { Brain, CheckCircle2, XCircle, Award, Sparkles, HelpCircle, ArrowRight } from 'lucide-react';

interface DailyPuzzleViewProps {
  currentStudent: Student | null;
  onSolvePuzzle: (puzzleId: string, rewardPoints: number, badgeUnlock?: string) => void;
  onNeedLogin: () => void;
}

export const DailyPuzzleView: React.FC<DailyPuzzleViewProps> = ({
  currentStudent,
  onSolvePuzzle,
  onNeedLogin
}) => {
  const [selectedAnswers, setSelectedAnswers] = useState<{ [puzzleId: string]: number }>({});
  const [submittedStatus, setSubmittedStatus] = useState<{ [puzzleId: string]: boolean }>({});

  const handleSelectOption = (puzzleId: string, index: number) => {
    setSelectedAnswers(prev => ({ ...prev, [puzzleId]: index }));
  };

  const handleSubmitPuzzle = (puzzle: DailyPuzzle) => {
    if (!currentStudent) {
      onNeedLogin();
      return;
    }

    const selectedIndex = selectedAnswers[puzzle.id];
    if (selectedIndex === undefined) return;

    const isCorrect = selectedIndex === puzzle.correctIndex;
    setSubmittedStatus(prev => ({ ...prev, [puzzle.id]: true }));

    if (isCorrect && !currentStudent.solvedPuzzles.includes(puzzle.id)) {
      onSolvePuzzle(puzzle.id, puzzle.rewardPoints, puzzle.badgeUnlock);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white rounded-3xl p-6 sm:p-8 shadow-lg">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 bg-white/20 rounded-2xl backdrop-blur-xs">
            <Brain className="w-6 h-6 text-amber-100" />
          </div>
          <div>
            <h2 className="text-2xl sm:text-3xl font-black">Teka-Teki Logika Harian</h2>
            <p className="text-amber-100 text-xs sm:text-sm">
              Asah kemampuan algoritma & komputasional dengan studi kasus menarik sehari-hari!
            </p>
          </div>
        </div>
      </div>

      {/* Puzzle List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {DAILY_PUZZLES.map(puzzle => {
          const isSolvedBefore = currentStudent?.solvedPuzzles.includes(puzzle.id);
          const userSelectedIndex = selectedAnswers[puzzle.id];
          const isSubmitted = submittedStatus[puzzle.id];
          const isCorrect = userSelectedIndex === puzzle.correctIndex;

          return (
            <div
              key={puzzle.id}
              className={`bg-white rounded-3xl p-6 border transition-all duration-300 flex flex-col justify-between ${
                isSolvedBefore
                  ? 'border-emerald-300 shadow-sm bg-emerald-50/20'
                  : 'border-amber-200 shadow-md hover:shadow-lg'
              }`}
            >
              <div>
                {/* Header Badge */}
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-800 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" /> {puzzle.rewardPoints} XP
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700">
                      Kategori: {puzzle.difficulty}
                    </span>
                    {isSolvedBefore && (
                      <span className="text-xs font-extrabold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Selesai
                      </span>
                    )}
                  </div>
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-2">{puzzle.title}</h3>
                <p className="text-sm text-slate-700 leading-relaxed mb-4">{puzzle.story}</p>

                {puzzle.codeSnippet && (
                  <div className="bg-slate-900 text-amber-300 p-3 rounded-xl font-mono text-xs mb-4">
                    {puzzle.codeSnippet}
                  </div>
                )}

                <div className="font-semibold text-sm text-amber-950 mb-3 flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-amber-600" /> {puzzle.question}
                </div>

                {/* Options Radio List */}
                <div className="space-y-2 mb-6">
                  {puzzle.options.map((opt, idx) => {
                    const isSelected = userSelectedIndex === idx;
                    let optionStyle = 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-amber-50/60';

                    if (isSubmitted) {
                      if (idx === puzzle.correctIndex) {
                        optionStyle = 'bg-emerald-100 border-emerald-500 text-emerald-900 font-bold';
                      } else if (isSelected) {
                        optionStyle = 'bg-rose-100 border-rose-400 text-rose-900 font-semibold';
                      }
                    } else if (isSelected) {
                      optionStyle = 'bg-amber-100 border-amber-500 text-amber-950 font-bold ring-2 ring-amber-300';
                    }

                    return (
                      <button
                        key={idx}
                        onClick={() => handleSelectOption(puzzle.id, idx)}
                        disabled={isSubmitted || isSolvedBefore}
                        className={`w-full p-3 rounded-2xl border text-left text-xs sm:text-sm transition flex items-center justify-between ${optionStyle}`}
                      >
                        <span>{opt}</span>
                        {isSubmitted && idx === puzzle.correctIndex && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        )}
                        {isSubmitted && isSelected && idx !== puzzle.correctIndex && (
                          <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Action Button & Explanation */}
              <div>
                {!isSubmitted && !isSolvedBefore && (
                  <button
                    onClick={() => handleSubmitPuzzle(puzzle)}
                    disabled={userSelectedIndex === undefined}
                    className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-extrabold rounded-2xl text-xs sm:text-sm transition shadow-md disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    Kirim Jawaban <ArrowRight className="w-4 h-4" />
                  </button>
                )}

                {(isSubmitted || isSolvedBefore) && (
                  <div className="p-4 rounded-2xl bg-slate-900 text-slate-200 text-xs leading-relaxed space-y-2">
                    <div className="font-bold text-amber-400 flex items-center gap-1.5">
                      <Award className="w-4 h-4" /> Pembahasan Algoritma:
                    </div>
                    <p>{puzzle.explanation}</p>
                    {isCorrect && !isSolvedBefore && (
                      <div className="mt-2 text-emerald-400 font-bold">
                        🎉 Selamat! Jawaban Kamu Benar (+{puzzle.rewardPoints} XP)
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
