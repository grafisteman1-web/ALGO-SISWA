import React, { useState } from 'react';
import { LearningModule, Student } from '../types';
import { SequentialSim } from './simulations/SequentialSim';
import { BranchingSim } from './simulations/BranchingSim';
import { LoopingSim } from './simulations/LoopingSim';
import { SearchingSim } from './simulations/SearchingSim';
import { SortingSim } from './simulations/SortingSim';
import { FlowchartViewer } from './FlowchartViewer';
import {
  ListOrdered,
  GitFork,
  Repeat,
  Search,
  ArrowUpDown,
  BookOpen,
  Play,
  CheckCircle2,
  Code2,
  HelpCircle,
  Sparkles,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface ModuleCardProps {
  module: LearningModule;
  currentStudent: Student | null;
  onCompleteModule: (moduleId: string, points: number) => void;
  onNeedLogin: () => void;
}

export const ModuleCard: React.FC<ModuleCardProps> = ({
  module,
  currentStudent,
  onCompleteModule,
  onNeedLogin
}) => {
  const [activeTab, setActiveTab] = useState<'case' | 'flowchart' | 'simulation' | 'quiz'>('case');
  const [showPseudocode, setShowPseudocode] = useState<boolean>(false);

  // Quiz state
  const [quizAnswers, setQuizAnswers] = useState<{ [qId: string]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  const isCompleted = currentStudent?.completedModules.includes(module.id);

  const renderIcon = () => {
    switch (module.iconName) {
      case 'ListOrdered': return <ListOrdered className="w-6 h-6 text-emerald-600" />;
      case 'GitFork': return <GitFork className="w-6 h-6 text-blue-600" />;
      case 'Repeat': return <Repeat className="w-6 h-6 text-amber-600" />;
      case 'Search': return <Search className="w-6 h-6 text-purple-600" />;
      case 'ArrowUpDown': return <ArrowUpDown className="w-6 h-6 text-rose-600" />;
      default: return <BookOpen className="w-6 h-6 text-emerald-600" />;
    }
  };

  const handleQuizOptionSelect = (qId: string, optionIdx: number) => {
    setQuizAnswers(prev => ({ ...prev, [qId]: optionIdx }));
  };

  const handleCheckQuiz = () => {
    if (!currentStudent) {
      onNeedLogin();
      return;
    }

    setQuizSubmitted(true);

    // Calculate score
    let correctCount = 0;
    module.quiz.forEach(q => {
      if (quizAnswers[q.id] === q.correctAnswer) {
        correctCount++;
      }
    });

    if (correctCount === module.quiz.length && !isCompleted) {
      onCompleteModule(module.id, 50);
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-emerald-100 shadow-md overflow-hidden transition-all duration-300">
      {/* Module Header Bar */}
      <div className="p-6 bg-gradient-to-r from-emerald-50 via-teal-50 to-white border-b border-emerald-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-white rounded-2xl shadow-xs border border-emerald-100">{renderIcon()}</div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                {module.category}
              </span>
              {isCompleted && (
                <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-200 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Modul Tuntas
                </span>
              )}
            </div>
            <h3 className="text-xl font-extrabold text-slate-900">{module.title}</h3>
            <p className="text-xs text-slate-600 mt-1">{module.summary}</p>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-2xl border border-emerald-200">
          <button
            onClick={() => setActiveTab('case')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'case' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:bg-emerald-50'
            }`}
          >
            Kasus SMA
          </button>
          <button
            onClick={() => setActiveTab('flowchart')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              activeTab === 'flowchart' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:bg-emerald-50'
            }`}
          >
            Flowchart
          </button>
          <button
            onClick={() => setActiveTab('simulation')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
              activeTab === 'simulation' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-700 hover:bg-emerald-50'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" /> Simulasi
          </button>
          <button
            onClick={() => setActiveTab('quiz')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
              activeTab === 'quiz' ? 'bg-amber-500 text-white shadow-xs' : 'text-amber-800 hover:bg-amber-50'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> Kuis (+50 XP)
          </button>
        </div>
      </div>

      {/* Tab Body Content */}
      <div className="p-6">
        {/* Tab 1: SMA Case Study */}
        {activeTab === 'case' && (
          <div className="space-y-4">
            <div className="bg-emerald-50/80 p-5 rounded-2xl border border-emerald-100">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block mb-1">
                Studi Kasus Kehidupan Nyata Siswa SMA Kelas X
              </span>
              <h4 className="text-base font-extrabold text-slate-900 mb-2">{module.smaCaseTitle}</h4>
              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">{module.smaCaseDescription}</p>
            </div>

            {/* Pseudocode Accordion */}
            <div className="border border-slate-200 rounded-2xl overflow-hidden">
              <button
                onClick={() => setShowPseudocode(!showPseudocode)}
                className="w-full p-4 bg-slate-900 text-slate-100 font-mono text-xs font-bold flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Code2 className="w-4 h-4 text-emerald-400" /> Pseudocode Algoritma
                </div>
                {showPseudocode ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              {showPseudocode && (
                <div className="p-4 bg-slate-950 text-emerald-300 font-mono text-xs leading-relaxed overflow-x-auto space-y-1">
                  {module.pseudocode.map((line, idx) => (
                    <div key={idx}>{line}</div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setActiveTab('simulation')}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition"
              >
                Coba Simulasi Interaktif <Play className="w-4 h-4 fill-current" />
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Flowchart Viewer */}
        {activeTab === 'flowchart' && <FlowchartViewer nodes={module.flowchartNodes} />}

        {/* Tab 3: Interactive Simulations */}
        {activeTab === 'simulation' && (
          <div>
            {module.simulationType === 'sequential' && (
              <SequentialSim onComplete={() => onCompleteModule(module.id, 30)} />
            )}
            {module.simulationType === 'branching' && (
              <BranchingSim onComplete={() => onCompleteModule(module.id, 30)} />
            )}
            {module.simulationType === 'looping' && (
              <LoopingSim onComplete={() => onCompleteModule(module.id, 30)} />
            )}
            {module.simulationType === 'searching' && (
              <SearchingSim onComplete={() => onCompleteModule(module.id, 30)} />
            )}
            {module.simulationType === 'sorting' && (
              <SortingSim onComplete={() => onCompleteModule(module.id, 30)} />
            )}
          </div>
        )}

        {/* Tab 4: Quiz */}
        {activeTab === 'quiz' && (
          <div className="space-y-6">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between text-xs font-semibold text-amber-900">
              <span>Selesaikan kuis untuk menguji pemahaman dan dapatkan +50 XP!</span>
              <Sparkles className="w-5 h-5 text-amber-500 shrink-0" />
            </div>

            {module.quiz.map((q, qIdx) => (
              <div key={q.id} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <h5 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                  Soal #{qIdx + 1}: {q.question}
                </h5>

                <div className="space-y-2">
                  {q.options.map((opt, optIdx) => {
                    const isSelected = quizAnswers[q.id] === optIdx;
                    let optionStyle = 'bg-white border-slate-200 hover:bg-emerald-50/60';

                    if (quizSubmitted) {
                      if (optIdx === q.correctAnswer) {
                        optionStyle = 'bg-emerald-100 border-emerald-500 font-bold text-emerald-950';
                      } else if (isSelected) {
                        optionStyle = 'bg-rose-100 border-rose-400 text-rose-950';
                      }
                    } else if (isSelected) {
                      optionStyle = 'bg-emerald-100 border-emerald-500 font-bold text-emerald-950 ring-2 ring-emerald-300';
                    }

                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleQuizOptionSelect(q.id, optIdx)}
                        disabled={quizSubmitted}
                        className={`w-full p-3 rounded-xl border text-left text-xs sm:text-sm transition flex items-center justify-between ${optionStyle}`}
                      >
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>

                {quizSubmitted && (
                  <div className="p-3 bg-slate-900 text-slate-200 rounded-xl text-xs leading-relaxed mt-2">
                    <span className="font-bold text-amber-300 block mb-1">Pembahasan:</span>
                    {q.explanation}
                  </div>
                )}
              </div>
            ))}

            {!quizSubmitted && (
              <button
                onClick={handleCheckQuiz}
                className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white font-extrabold rounded-2xl text-xs sm:text-sm transition shadow-md"
              >
                Kirim & Periksa Jawaban Kuis
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
