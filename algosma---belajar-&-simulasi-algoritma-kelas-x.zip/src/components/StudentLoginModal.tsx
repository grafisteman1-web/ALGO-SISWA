import React, { useState } from 'react';
import { Student } from '../types';
import { ALL_CLASSES } from '../data/initialStudents';
import { findStudentByNisn } from '../lib/storage';
import { UserCheck, Search, KeyRound, AlertCircle, Sparkles, X } from 'lucide-react';

interface StudentLoginModalProps {
  students: Student[];
  onLoginSuccess: (student: Student) => void;
  onClose: () => void;
}

export const StudentLoginModal: React.FC<StudentLoginModalProps> = ({
  students,
  onLoginSuccess,
  onClose
}) => {
  const [nisnInput, setNisnInput] = useState<string>('');
  const [selectedClass, setSelectedClass] = useState<string>('X-1');
  const [selectedStudentNisn, setSelectedStudentNisn] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Filter student candidates by selected class
  const classStudents = students.filter(s => s.studentClass === selectedClass);

  const handleLoginByNisn = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const nisnToFind = selectedStudentNisn || nisnInput.trim();
    if (!nisnToFind) {
      setErrorMessage('Silakan masukkan atau pilih NISN Anda.');
      return;
    }

    const found = findStudentByNisn(nisnToFind) || students.find(s => s.nisn.trim() === nisnToFind.trim());

    if (found) {
      onLoginSuccess(found);
    } else {
      setErrorMessage(`NISN "${nisnToFind}" tidak ditemukan di database Book.csv. Pastikan NISN sudah benar.`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-emerald-200 relative animate-fade-in">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center mb-3">
            <UserCheck className="w-6 h-6" />
          </div>
          <h3 className="text-2xl font-black text-slate-900">Login Siswa (NISN)</h3>
          <p className="text-xs text-slate-600 mt-1">
            Gunakan Nomor Induk Siswa Nasional (NISN) dari daftar Book.csv
          </p>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleLoginByNisn} className="space-y-4">
          {/* Method 1: Direct NISN input */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Opsi 1: Ketik NISN Siswa</label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Contoh: 0114726628"
                value={nisnInput}
                onChange={e => {
                  setNisnInput(e.target.value);
                  setSelectedStudentNisn('');
                }}
                className="w-full pl-9 pr-4 py-2.5 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="text-center text-xs font-bold text-slate-400 my-2">-- ATAU PILIH NAMA DARI KELAS --</div>

          {/* Method 2: Select Class & Name */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Pilih Kelas:</label>
              <select
                value={selectedClass}
                onChange={e => {
                  setSelectedClass(e.target.value);
                  setSelectedStudentNisn('');
                }}
                className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-bold text-slate-900"
              >
                {ALL_CLASSES.filter(c => c !== 'Semua Kelas').map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Pilih Nama Siswa:</label>
              <select
                value={selectedStudentNisn}
                onChange={e => {
                  setSelectedStudentNisn(e.target.value);
                  setNisnInput(e.target.value);
                }}
                className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-bold text-slate-900 truncate"
              >
                <option value="">-- Pilih Siswa --</option>
                {classStudents.map(st => (
                  <option key={st.nisn} value={st.nisn}>
                    {st.name} ({st.nisn})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full mt-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-2xl text-xs sm:text-sm transition shadow-md flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-300" /> Masuk Aplikasi
          </button>
        </form>
      </div>
    </div>
  );
};
