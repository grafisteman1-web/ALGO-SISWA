import React, { useState } from 'react';
import { TeacherUser } from '../types';
import { ShieldCheck, Mail, Lock, Sparkles, X } from 'lucide-react';

interface TeacherLoginModalProps {
  onLoginSuccess: (teacher: TeacherUser) => void;
  onClose: () => void;
}

export const TeacherLoginModal: React.FC<TeacherLoginModalProps> = ({
  onLoginSuccess,
  onClose
}) => {
  const [emailInput, setEmailInput] = useState<string>('grafisteman1@gmail.com');
  const [nameInput, setNameInput] = useState<string>('Bapak/Ibu Guru Informatika');

  const handleTeacherLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput.trim()) return;

    onLoginSuccess({
      email: emailInput.trim(),
      name: nameInput.trim() || 'Guru Informatika',
      role: 'teacher'
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-emerald-200 relative animate-fade-in">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 rounded-full transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 mx-auto flex items-center justify-center mb-3">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-2xl font-black text-slate-900">Login Guru / Admin</h3>
          <p className="text-xs text-slate-600 mt-1">
            Akses Panel Guru & Pengelolaan Google Sheets Rekap Nilai
          </p>
        </div>

        <form onSubmit={handleTeacherLogin} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Email Google / Gmail Guru:</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                placeholder="nama@gmail.com"
                value={emailInput}
                onChange={e => setEmailInput(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Nama Lengkap Guru:</label>
            <input
              type="text"
              required
              value={nameInput}
              onChange={e => setNameInput(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <button
            type="submit"
            className="w-full mt-4 py-3 bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold rounded-2xl text-xs sm:text-sm transition shadow-md flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-4 h-4 text-amber-300" /> Masuk Panel Guru
          </button>
        </form>
      </div>
    </div>
  );
};
