import React, { useState } from 'react';
import { Student, TeacherUser } from '../types';
import {
  addStudentByTeacher,
  updateStudentByTeacher,
  deleteStudentByTeacher,
  saveStudentsToStorage
} from '../lib/storage';
import { ALL_CLASSES } from '../data/initialStudents';
import {
  ShieldCheck,
  Users,
  FileSpreadsheet,
  Plus,
  Trash2,
  Edit2,
  Search,
  Download,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sparkles
} from 'lucide-react';

interface TeacherDashboardProps {
  teacher: TeacherUser;
  students: Student[];
  onStudentsChange: (newStudents: Student[]) => void;
  isOnline: boolean;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  teacher,
  students,
  onStudentsChange,
  isOnline
}) => {
  const [selectedClassFilter, setSelectedClassFilter] = useState<string>('Semua Kelas');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportMessage, setExportMessage] = useState<string | null>(null);

  // Add/Edit Student Modal state
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Form Fields
  const [formName, setFormName] = useState<string>('');
  const [formNisn, setFormNisn] = useState<string>('');
  const [formGender, setFormGender] = useState<'L' | 'P'>('L');
  const [formClass, setFormClass] = useState<string>('X-1');

  // Filter students
  const filteredStudents = students.filter(s => {
    const matchClass = selectedClassFilter === 'Semua Kelas' || s.studentClass === selectedClassFilter;
    const matchQuery =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.nisn.toLowerCase().includes(searchQuery.toLowerCase());
    return matchClass && matchQuery;
  });

  const handleOpenAddModal = () => {
    setEditingStudent(null);
    setFormName('');
    setFormNisn('');
    setFormGender('L');
    setFormClass('X-1');
    setShowAddModal(true);
  };

  const handleOpenEditModal = (st: Student) => {
    setEditingStudent(st);
    setFormName(st.name);
    setFormNisn(st.nisn);
    setFormGender(st.gender);
    setFormClass(st.studentClass);
    setShowAddModal(true);
  };

  const handleSaveStudentForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formNisn.trim()) return;

    if (editingStudent) {
      const updated: Student = {
        ...editingStudent,
        name: formName.trim(),
        nisn: formNisn.trim(),
        gender: formGender,
        studentClass: formClass
      };
      updateStudentByTeacher(updated);
    } else {
      addStudentByTeacher({
        id: formNisn.trim(),
        name: formName.trim(),
        nisn: formNisn.trim(),
        gender: formGender,
        studentClass: formClass
      });
    }

    const latest = students; // re-fetch from storage in reality
    const updatedAll = students.map(s => (s.id === editingStudent?.id ? { ...s, name: formName, nisn: formNisn, gender: formGender, studentClass: formClass } : s));
    onStudentsChange(updatedAll);
    setShowAddModal(false);
  };

  const handleDeleteStudent = (nisn: string) => {
    if (window.confirm(`Yakin ingin menghapus data siswa NISN: ${nisn}?`)) {
      deleteStudentByTeacher(nisn);
      onStudentsChange(students.filter(s => s.nisn !== nisn));
    }
  };

  // Google Sheets Export
  const handleExportToGoogleSheets = async () => {
    setIsExporting(true);
    setExportMessage(null);

    try {
      const response = await fetch('/api/gsheet/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          students: filteredStudents,
          teacherName: teacher.name
        })
      });

      const data = await response.json();

      if (data.success && data.csvData) {
        // Trigger CSV download backup directly
        const blob = new Blob([data.csvData], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `Rekap_Nilai_AlgoSMA_${selectedClassFilter.replace(' ', '_')}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        setExportMessage(`Berhasil merekap & mendownload data ${data.syncedCount} siswa ke Google Sheets CSV!`);
      } else {
        setExportMessage('Gagal mengeksport data.');
      }
    } catch (err: any) {
      console.error(err);
      setExportMessage('Terjadi kesalahan koneksi export.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Panel */}
      <div className="bg-gradient-to-r from-emerald-900 via-teal-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-500/30 rounded-2xl border border-emerald-400/40">
              <ShieldCheck className="w-8 h-8 text-amber-300" />
            </div>
            <div>
              <span className="text-xs font-bold text-amber-300 bg-emerald-800/80 px-2.5 py-0.5 rounded-full uppercase">
                Akses Terverifikasi Guru / Admin
              </span>
              <h2 className="text-2xl sm:text-3xl font-black mt-1">Panel Guru & Pengelolaan Data Siswa</h2>
              <p className="text-emerald-200 text-xs sm:text-sm">
                Login: {teacher.email} ({teacher.name})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportToGoogleSheets}
              disabled={isExporting}
              className="px-5 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-2xl text-xs sm:text-sm transition shadow-lg flex items-center gap-2 disabled:opacity-50"
            >
              {isExporting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
              Export ke Google Sheets
            </button>
            <button
              onClick={handleOpenAddModal}
              className="px-4 py-3 bg-white/10 hover:bg-white/20 text-white font-bold rounded-2xl text-xs sm:text-sm border border-white/20 transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4 text-amber-300" /> Tambah Siswa
            </button>
          </div>
        </div>
      </div>

      {exportMessage && (
        <div className="p-4 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-2xl flex items-center justify-between text-xs sm:text-sm font-semibold">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{exportMessage}</span>
          </div>
          <button onClick={() => setExportMessage(null)} className="text-emerald-700 hover:text-emerald-900 font-extrabold">
            Tutup
          </button>
        </div>
      )}

      {/* Overview Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-emerald-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-100 text-emerald-700 rounded-2xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 block uppercase">Total Siswa Terdaftar</span>
            <span className="text-2xl font-black text-slate-900">{students.length} Siswa</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-emerald-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-100 text-amber-700 rounded-2xl">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 block uppercase">Rata-rata XP Siswa</span>
            <span className="text-2xl font-black text-slate-900">
              {Math.round(students.reduce((acc, curr) => acc + (curr.points || 0), 0) / (students.length || 1))} XP
            </span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-emerald-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-purple-100 text-purple-700 rounded-2xl">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 block uppercase">Sinkronisasi Data</span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full block mt-1 w-fit">
              Otomatis & Realtime
            </span>
          </div>
        </div>
      </div>

      {/* Filter & Table Bar */}
      <div className="bg-white p-4 rounded-2xl border border-emerald-100 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs font-bold text-slate-700 shrink-0">Filter Kelas:</span>
          <select
            value={selectedClassFilter}
            onChange={e => setSelectedClassFilter(e.target.value)}
            className="px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-900"
          >
            {ALL_CLASSES.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-emerald-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari NISN / Nama Siswa..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-950"
          />
        </div>
      </div>

      {/* Students Data Table */}
      <div className="bg-white rounded-3xl border border-emerald-100 shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-emerald-50 text-emerald-950 font-extrabold uppercase border-b border-emerald-100">
              <tr>
                <th className="p-4">NISN</th>
                <th className="p-4">Nama Lengkap</th>
                <th className="p-4">L/P</th>
                <th className="p-4">Kelas</th>
                <th className="p-4 text-center">Total XP</th>
                <th className="p-4 text-center">Modul Tuntas</th>
                <th className="p-4 text-right">Aksi Guru</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-emerald-50 text-slate-800 font-medium">
              {filteredStudents.map(st => (
                <tr key={st.id || st.nisn} className="hover:bg-emerald-50/40 transition">
                  <td className="p-4 font-mono font-bold text-emerald-900">{st.nisn}</td>
                  <td className="p-4 font-bold text-slate-900">{st.name}</td>
                  <td className="p-4">{st.gender}</td>
                  <td className="p-4">
                    <span className="bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full text-xs">
                      {st.studentClass}
                    </span>
                  </td>
                  <td className="p-4 text-center font-black text-amber-600">{st.points || 0} XP</td>
                  <td className="p-4 text-center font-bold text-emerald-700">
                    {(st.completedModules || []).length} Modul
                  </td>
                  <td className="p-4 text-right space-x-1">
                    <button
                      onClick={() => handleOpenEditModal(st)}
                      className="p-1.5 hover:bg-emerald-100 text-emerald-700 rounded-lg transition"
                      title="Edit Data Siswa"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteStudent(st.nisn)}
                      className="p-1.5 hover:bg-rose-100 text-rose-600 rounded-lg transition"
                      title="Hapus Siswa"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-emerald-200">
            <h3 className="text-lg font-black text-slate-900 mb-4">
              {editingStudent ? 'Edit Data Siswa' : 'Tambah Siswa Baru (Book.csv)'}
            </h3>

            <form onSubmit={handleSaveStudentForm} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">NISN Siswa:</label>
                <input
                  type="text"
                  required
                  value={formNisn}
                  onChange={e => setFormNisn(e.target.value)}
                  className="w-full px-3.5 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-slate-900"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Nama Lengkap Siswa:</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  className="w-full px-3.5 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Jenis Kelamin:</label>
                  <select
                    value={formGender}
                    onChange={e => setFormGender(e.target.value as any)}
                    className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    <option value="L">Laki-laki (L)</option>
                    <option value="P">Perempuan (P)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Kelas:</label>
                  <select
                    value={formClass}
                    onChange={e => setFormClass(e.target.value)}
                    className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    {ALL_CLASSES.filter(c => c !== 'Semua Kelas').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold transition shadow-md"
                >
                  Simpan Data
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
