import React, { useState, useEffect, useRef } from 'react';
import { AskAIMessage, Student } from '../types';
import { getStoredAIChat, saveAIChatToStorage } from '../lib/storage';
import { Bot, Send, User, Sparkles, X, Minimize2, Maximize2, RefreshCw, MessageSquare } from 'lucide-react';

interface AskAIWidgetProps {
  currentStudent: Student | null;
  topicContext?: string;
  isOnline: boolean;
}

export const AskAIWidget: React.FC<AskAIWidgetProps> = ({
  currentStudent,
  topicContext,
  isOnline
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [messages, setMessages] = useState<AskAIMessage[]>([]);
  const [inputText, setInputText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = getStoredAIChat();
    if (saved.length > 0) {
      setMessages(saved);
    } else {
      setMessages([
        {
          id: 'welcome-msg',
          sender: 'ai',
          text: `Halo ${currentStudent?.name || 'Siswa SMA'}! Saya AlgoBot AI 🤖. Ada pertanyaan seputar Algoritma Sekuensial, Percabangan, Perulangan, Pencarian, atau Pengurutan? Silakan tanyakan ya!`,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [currentStudent]);

  useEffect(() => {
    if (messages.length > 0) {
      saveAIChatToStorage(messages);
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async (promptToSend?: string) => {
    const query = (promptToSend || inputText).trim();
    if (!query) return;

    const userMsg: AskAIMessage = {
      id: 'msg-' + Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    if (!isOnline) {
      // Offline Smart Response Fallback
      setTimeout(() => {
        let offlineText = 'Maaf, kamu sedang dalam mode Offline. Namun berikut rangkuman singkat seputar konsep algoritma:\n\n';
        if (query.toLowerCase().includes('sekuensial')) {
          offlineText += '• Algoritma Sekuensial: Langkah-langkah instruksi dieksekusi dari baris pertama sampai akhir secara berurutan.';
        } else if (query.toLowerCase().includes('cabang') || query.toLowerCase().includes('if')) {
          offlineText += '• Algoritma Percabangan (If-Else): Memilih salah satu cabang perintah berdasarkan pengujian kondisi Benar atau Salah.';
        } else if (query.toLowerCase().includes('ulang') || query.toLowerCase().includes('loop')) {
          offlineText += '• Algoritma Perulangan (Looping): Mengulang aksi (seperti lari keliling lapangan) selama kondisi terpenuhi.';
        } else if (query.toLowerCase().includes('cari') || query.toLowerCase().includes('search')) {
          offlineText += '• Pencarian: Linear Search memeriksa satu per satu, sedangkan Binary Search membagi data terurut menjadi dua bagian.';
        } else {
          offlineText += '• Algoritma adalah urutan langkah-langkah logis untuk menyelesaikan permasalahan komputasional secara terstruktur.';
        }

        const aiReply: AskAIMessage = {
          id: 'ai-' + Date.now(),
          sender: 'ai',
          text: offlineText,
          timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, aiReply]);
        setIsLoading(false);
      }, 800);
      return;
    }

    try {
      const response = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: query,
          studentName: currentStudent?.name,
          studentClass: currentStudent?.studentClass,
          topicContext: topicContext || 'Materi Algoritma SMA'
        })
      });

      const data = await response.json();
      const replyText = data.reply || 'Terima kasih atas pertanyaannya!';

      const aiMsg: AskAIMessage = {
        id: 'ai-' + Date.now(),
        sender: 'ai',
        text: replyText,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      console.error('Error in Ask AI:', err);
      const errorMsg: AskAIMessage = {
        id: 'ai-err-' + Date.now(),
        sender: 'ai',
        text: 'Terjadi kendala saat menghubungi AlgoBot AI Server. Coba tanyakan kembali ya!',
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const PRESET_QUESTIONS = [
    'Apa perbedaan Linear Search & Binary Search?',
    'Berikan contoh algoritma percabangan di sekolah',
    'Bagaimana cara kerja Bubble Sort?',
    'Apa fungsi utama looping (perulangan)?'
  ];

  return (
    <>
      {/* Floating Launcher Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-4 rounded-full shadow-2xl hover:scale-105 transition flex items-center gap-2 group ring-4 ring-emerald-300/40"
        >
          <Bot className="w-6 h-6 animate-bounce" />
          <span className="font-extrabold text-xs pr-1 hidden sm:inline">Tanya AlgoBot AI</span>
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping absolute -top-1 -right-1" />
        </button>
      )}

      {/* Docked Floating Chat Modal */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-full max-w-sm sm:max-w-md bg-white rounded-3xl shadow-2xl border border-emerald-200 overflow-hidden flex flex-col h-[520px] animate-fade-in">
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-700 to-teal-700 text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-emerald-500/30 flex items-center justify-center border border-emerald-400/40">
                <Bot className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm flex items-center gap-1.5">
                  AlgoBot AI <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                </h4>
                <p className="text-[10px] text-emerald-200">
                  {isOnline ? 'Online • Berbasis Gemini 2.5 Flash' : 'Offline Mode • Jawaban Konsep'}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 text-emerald-200 hover:text-white hover:bg-emerald-600 rounded-xl transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Preset Questions Chips */}
          <div className="bg-emerald-50/60 p-2 border-b border-emerald-100 flex items-center gap-1.5 overflow-x-auto text-[11px] font-semibold text-emerald-800">
            <span className="shrink-0 text-[10px] text-emerald-600 font-bold px-1">Topik:</span>
            {PRESET_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(q)}
                disabled={isLoading}
                className="shrink-0 px-2.5 py-1 bg-white border border-emerald-200 hover:bg-emerald-100 rounded-full text-emerald-900 transition"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Chat Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50">
            {messages.map(msg => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2 ${isUser ? 'flex-row-reverse' : ''}`}
                >
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                      isUser ? 'bg-emerald-600 text-white' : 'bg-teal-700 text-amber-300'
                    }`}
                  >
                    {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>

                  <div
                    className={`max-w-[80%] p-3 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                      isUser
                        ? 'bg-emerald-600 text-white rounded-tr-none shadow-xs'
                        : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none shadow-xs'
                    }`}
                  >
                    {msg.text}
                    <span
                      className={`block text-[9px] mt-1 text-right ${
                        isUser ? 'text-emerald-200' : 'text-slate-400'
                      }`}
                    >
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              );
            })}

            {isLoading && (
              <div className="flex items-center gap-2 text-xs text-emerald-700 font-semibold p-2 bg-emerald-100/50 rounded-xl w-fit">
                <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
                AlgoBot sedang berpikir...
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input Box */}
          <div className="p-3 bg-white border-t border-emerald-100 flex items-center gap-2">
            <input
              type="text"
              placeholder="Ketik pertanyaan algoritma..."
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 px-3.5 py-2 bg-emerald-50/50 border border-emerald-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={isLoading || !inputText.trim()}
              className="p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl transition shadow-xs disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};
